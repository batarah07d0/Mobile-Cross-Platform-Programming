Menggunakan Supabase untuk Database
